import edu.duke.Point;
 
/**
 * A simple class that shows how to user FloorMap
 *
 * @author yonas tadesse
 * @version 0.1
 */
public class SimpleKivaClient extends RemoteControl
{
    public final static String BAD= "arfawsaffasaafsfadafffaaf";
    public final static  String MAP02 =   
                                   "---------------\n"
                                + "|K    P       |\n"
                                + "|     D       |\n"
                                + "|             |\n"
                                + "|             |\n"
                                + "|             |\n"
                                + "|             |\n"
                                + "|             |\n"
                                + "---------------";
    public FloorMap createMap(String theMap)
    {
          FloorMap init_map;
          init_map = new FloorMap(theMap);
          return init_map;
    }
    
    public Point [] checkForThings(FloorMap theMap )
    {
          Point init =theMap.getInitialKivaLocation();
          Point pod  =theMap.getPodLocation();
          Point drop =theMap.getDropZoneLocation();
          return new Point [] { init, pod, drop};
          
    }
     
    public void goTo(FloorMap theMap,Point target )
    {
        FloorMapObject theObject = theMap.getObjectAtLocation(target);
           switch (theObject) 
          {
                    
                    case OBSTACLE: 
                      throw new IllegalMoveException("Wait a minute! You sent me to an obstacle");
                    
                    default: break;
                    
                  }
    }
    public boolean run(FloorMap theMap) 
    {
           boolean isPod= false;
           Point init =theMap.getInitialKivaLocation();
           for (int column = init.getY(); column <= theMap.getMaxColNum(); column++) 
           {
               for (int row = init.getX(); row <= theMap.getMaxRowNum(); row++) 
               {
                  Point current = new Point(column,row);
                  FloorMapObject theObject= theMap.getObjectAtLocation(current);
                  
                  switch (theObject) 
                  {
                    case EMPTY: break; //do nothing
                    case OBSTACLE: System.out.println("Take care of the obstacle"); break;
                    case POD: System.out.println("Great you have founded the POD");  
                        isPod=true;
                        break;
                    case DROP_ZONE: System.out.println("You need to arrive here!"); break;
                    default: break;
                    
                  }
                }
           }
           return isPod;
    }
    public void simulate(String theMap)
    {
        try 
        {
          FloorMap map=createMap(theMap);
          Point [] theObjects=checkForThings(map);
          for (int i=0 ; i<theObjects.length; i++)
          {
               System.out.println(theObjects[i]);
          }
          

        } catch (InvalidMapLayoutException ex) 
        {
            System.err.println(ex);
            System.err.println("This map doesn´t have a correct layout");
        }
        
    }
}