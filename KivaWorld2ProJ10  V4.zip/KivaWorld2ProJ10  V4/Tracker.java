import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
import edu.duke.Point;

/**
 * Write a description of class Tracker here.
 * Read
 * Eval
 * Print
 * Loop
 * REPL
 * @author (your name)
 * @version (a version number or a date)
 */
public class Tracker
{
    
    //A generic ArrayList
    private ArrayList<Point> records;
    private HashMap<String, Point> namedPoints;
    private TreeMap<FloorMapObject, Point > locations; 
    
    public Tracker()
    {
        this.records = new ArrayList<Point>();
        this.namedPoints = new HashMap<String, Point> ();
        this.locations = new TreeMap<FloorMapObject,Point>();
        //ArrayList <Object> local = new ArrayList<Object>();
    }
    
    public void track(Point aPoint)
    {
        this.records.add(aPoint);
    }
    
    public ArrayList<Point>  getRecords()
    {
        return records;
    }
    
    public void nameTo(String key,Point aPoint)
    {
        this.namedPoints.put(key,aPoint);
    }
    
    public HashMap<String, Point>  getNamedPoints()
    {
        return this.namedPoints;
    }
    
    public void record ( FloorMapObject keytype, Point thePoint) 
    {
        this.locations.put(keytype,thePoint );
    }
    
    public TreeMap<FloorMapObject, Point >  getLocations()
    {
        return this.locations;
    }
   
}