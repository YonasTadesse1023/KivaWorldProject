import edu.duke.Point;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.lang.Iterable;
/**
 * Write a description of class MainSystem here.
 *
 * @author (yonas tadesse)
 * @version (09/20/2018)
 */
public class MainSystem extends RemoteControl
{
   public static void main(String [] args)
   {
       Point p00 = new Point(0,0); Point p01 = new Point(3,3); Point p02 = new Point(9,9);  Point p03 = new Point(81,81); 
       
       Tracker theTracker = new Tracker();
       theTracker.track(p00); theTracker.track(p01); theTracker.track(p02); theTracker.track(p03);
       System.out.println("Tracked points # " + theTracker.getRecords().size());
       int length = theTracker.getRecords().size();
       for (int i = 0; i <length; i++) 
       {
           System.out.println( " i "+ i + "---> " + theTracker.getRecords().get(i) );
       }
       for ( Point p : theTracker.getRecords() )
       {
           System.out.println(p);
       }
       
       theTracker.record(FloorMapObject.POD, p01);
       theTracker.record(FloorMapObject.DROP_ZONE, p03);
       theTracker.record(FloorMapObject.OBSTACLE, p02);
       theTracker.record(FloorMapObject.EMPTY, p00);
       for ( FloorMapObject key: theTracker.getLocations().keySet() )
       {
           System.out.println(key);
           System.out.println(theTracker.getLocations().get(key));
       }
       
       theTracker.nameTo("hulk", p03);
       theTracker.nameTo("black widow", p01);
       for ( String index : theTracker.getNamedPoints().keySet() )
       {
           System.out.println(index);
           System.out.println(theTracker.getNamedPoints().get(index));
       }
       
       List<Point> records=theTracker.getRecords();
       for ( Point p : records) 
       {
           System.out.println(p);
       }
       
      Map<String, Point> namedPoints=theTracker.getNamedPoints();
      Map<FloorMapObject,Point> locations = theTracker.getLocations();
      
      Set<String> keyNames=namedPoints.keySet();
      for ( String  name : keyNames)
      {
          System.out.println(name);
          System.out.println(namedPoints.get(name));
      }
      Iterable<FloorMapObject> iAmIterable = locations.keySet();
      for ( FloorMapObject  type : iAmIterable)
      {
          System.out.println(type);
          System.out.println(namedPoints.get(type));
      }
   }
}